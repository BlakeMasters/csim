from cellsim.backends.native import NativeReferenceBackend
from cellsim.core.scheduler import MultiRateScheduler
from cellsim.core.state import CellState, GeometryState, ScalarFieldState, WorldState
from cellsim.core.fidelity import FidelityController
from cellsim.processes.mechanics import MechanicsProcess
from cellsim.processes.transport import UniformDecayTransport
from cellsim.processes.intracellular import HypoxiaResponse


def build_world() -> WorldState:
    cells = {
        "c0": CellState("c0", (0.0, 0.0, 0.0), geometry=GeometryState(radius=1.0)),
        "c1": CellState("c1", (1.5, 0.0, 0.0), geometry=GeometryState(radius=1.0)),
    }
    oxygen = ScalarFieldState("oxygen", "normalized", {"c0": 0.10, "c1": 0.80})
    return WorldState(cells=cells, scalar_fields={"oxygen": oxygen})


def main() -> None:
    state = build_world()
    backend = NativeReferenceBackend()
    scheduler = MultiRateScheduler([
        MechanicsProcess(backend, dt=0.01),
        UniformDecayTransport("oxygen", decay_rate=0.001, dt=0.1),
        HypoxiaResponse(threshold=0.2, dt=1.0),
    ])
    logs = scheduler.advance(state, until=1.0)

    controller = FidelityController()
    level, decision = controller.choose({"strain": 0.25, "gradient": 0.4})

    print("time:", state.time)
    print("cells:", {k: v.position for k, v in state.cells.items()})
    print("phenotypes:", {k: v.phenotype for k, v in state.cells.items()})
    print("fidelity:", level.name, decision["reason"])
    print("processes:", sorted(logs))


if __name__ == "__main__":
    main()
