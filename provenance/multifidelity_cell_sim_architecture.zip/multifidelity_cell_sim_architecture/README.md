# Multi-Fidelity Cellular Simulation Architecture

A from-scratch architecture for a comprehensive cellular simulation environment that uses specialist simulators as **reference solvers and validation oracles**, not as the owner of the biological world state.

## Design goals

- One canonical biological/environment state.
- Native high-throughput execution path suitable for custom Warp/CUDA/CPU kernels.
- Swappable specialist solvers for difficult local regimes (SOFA, ESPResSo, Tissue Forge, etc.).
- Explicit multirate scheduling across mechanics, transport, signaling, phenotype, and discrete events.
- Adaptive fidelity escalation based on uncertainty, strain, gradients, flow regime, or validation envelope.
- Reproducible qualification against analytic solutions, independent engines, and experiments.
- External entities and interventions represented through typed physical interfaces instead of direct state mutation.

## Repository map

```text
src/cellsim/core/       Canonical state, processes, scheduler, fidelity, conservation
src/cellsim/processes/  Mechanics, transport, intracellular dynamics, discrete events
src/cellsim/backends/   Native and specialist-solver adapter interfaces
schemas/                JSON schemas for canonical state and experiments
config/experiments/     Example experiment configurations
benchmarks/             Qualification corpus manifests
docs/                   Architecture, coupling, fidelity, validation, roadmap
examples/                Minimal runnable demonstration
tests/                   Architecture-level tests
```

## Intended execution model

```text
Experiment / Intervention API
            |
            v
Canonical biological state
  |         |          |
  v         v          v
Mechanics  Transport  Intracellular
  |         |          |
  +---- Native engine -+
            |
      Fidelity controller
       /       |       \
    SOFA    ESPResSo   Tissue Forge
       \       |       /
        reference/correction
            |
     Qualification store
```

## Minimal runnable scaffold

The included Python implementation is deliberately dependency-light and models the orchestration architecture, not production-grade cell physics.

```bash
python -m examples.run_microtumor
python -m unittest discover -s tests -v
```

For a production implementation, replace the native backend placeholder with Warp/custom kernels and implement adapters behind `SolverBackend`.
