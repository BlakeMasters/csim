# Agent Guidelines

## Project objective

Build a scientifically qualified multi-fidelity cellular simulation engine. The core system must own the biological state and experiment semantics; external simulation packages are specialist solvers or validation references.

## Invariants

1. No backend may mutate canonical state directly. Backends return typed deltas or observations.
2. Every physical quantity crossing an interface must declare units.
3. Mass/energy/species accounting must be checkable when the modeled process is conservative.
4. Discrete events (division, death, mutation, entry/exit) are separated from continuous integration.
5. High-fidelity escalation decisions must be logged with reason, region/entity scope, and solver version.
6. A learned surrogate cannot silently replace a qualified solver outside its validation envelope.
7. All benchmarks include timestep/resolution convergence expectations where applicable.
8. Simulation claims are tied to explicit qualification envelopes, never to a scalar "realism" score.

## Preferred implementation sequence

1. Canonical state and process contracts.
2. Deterministic scheduler and replay.
3. Native coarse mechanics + diffusion.
4. Conservation checks and analytic benchmarks.
5. Specialist solver adapters.
6. Cross-engine qualification corpus.
7. Adaptive fidelity controller.
8. Learned reduced-order corrections only after reference data exists.
