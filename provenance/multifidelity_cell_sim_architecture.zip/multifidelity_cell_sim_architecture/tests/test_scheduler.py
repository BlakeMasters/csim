import unittest

from cellsim.core.scheduler import MultiRateScheduler
from cellsim.core.state import ScalarFieldState, WorldState
from cellsim.processes.transport import UniformDecayTransport


class SchedulerTests(unittest.TestCase):
    def test_multirate_process_executes(self):
        state = WorldState(scalar_fields={"x": ScalarFieldState("x", "u", {"p": 1.0})})
        s = MultiRateScheduler([UniformDecayTransport("x", decay_rate=0.1, dt=0.5)])
        s.advance(state, until=1.0)
        self.assertLess(state.scalar_fields["x"].values["p"], 1.0)
        self.assertEqual(state.time, 1.0)


if __name__ == "__main__":
    unittest.main()
