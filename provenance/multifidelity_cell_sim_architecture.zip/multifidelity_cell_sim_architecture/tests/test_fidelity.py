import unittest

from cellsim.core.fidelity import FidelityController, FidelityLevel


class FidelityTests(unittest.TestCase):
    def test_escalation(self):
        c = FidelityController()
        self.assertEqual(c.choose({"strain": 0.1})[0], FidelityLevel.F0_COARSE_NATIVE)
        self.assertEqual(c.choose({"strain": 0.25})[0], FidelityLevel.F1_DETAILED_NATIVE)
        self.assertEqual(c.choose({"strain": 0.50})[0], FidelityLevel.F2_SPECIALIST)
        self.assertEqual(c.choose({"reference_disagreement": 0.20})[0], FidelityLevel.F3_REFINED_SPECIALIST)


if __name__ == "__main__":
    unittest.main()
