import unittest

from cellsim.core.conservation import compare_species
from cellsim.core.state import CellState, ScalarFieldState, WorldState


class ConservationTests(unittest.TestCase):
    def test_species_accounting(self):
        before = WorldState(
            cells={"c": CellState("c", (0, 0, 0), molecular={"drug": 1.0})},
            scalar_fields={"drug": ScalarFieldState("drug", "u", {"v0": 2.0})},
        )
        after = before.clone()
        after.cells["c"].molecular["drug"] = 2.0
        after.scalar_fields["drug"].values["v0"] = 1.0
        r = compare_species(before, after, "drug")
        self.assertAlmostEqual(r.relative_error, 0.0)


if __name__ == "__main__":
    unittest.main()
