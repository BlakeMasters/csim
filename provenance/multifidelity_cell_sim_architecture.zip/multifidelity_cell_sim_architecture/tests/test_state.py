import unittest

from cellsim.core.state import CellState, StateDelta, WorldState


class StateTests(unittest.TestCase):
    def test_delta_commit(self):
        state = WorldState(cells={"a": CellState("a", (0, 0, 0))})
        delta = StateDelta(position_updates={"a": (1, 2, 3)})
        delta.commit(state)
        self.assertEqual(state.cells["a"].position, (1, 2, 3))


if __name__ == "__main__":
    unittest.main()
