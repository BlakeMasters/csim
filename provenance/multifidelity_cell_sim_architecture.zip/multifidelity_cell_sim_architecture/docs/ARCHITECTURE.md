# Comprehensive Architecture

## 1. System boundary

The system is a **simulation operating layer**, not a cancer-specific simulator. Cancer biology is represented as one model family assembled from general processes and entities.

The canonical state is the single source of truth. Numerical backends consume snapshots/views and return typed `StateDelta` objects. This prevents solver-specific data structures from becoming the biological model.

## 2. Canonical world model

```text
WorldState
├── entities
│   ├── cells
│   ├── external physical entities
│   └── boundaries / vessels / scaffolds
├── fields
│   ├── scalar chemical fields
│   ├── vector flow fields
│   └── tensor stress fields
├── topology
│   ├── contact graph
│   ├── lineage graph
│   └── vessel / ECM structures
├── clock
└── provenance
```

A cell is composed from orthogonal state groups:

- geometry
- mechanical/material state
- membrane state
- intracellular molecular state
- phenotype
- interaction parameters
- lineage/provenance

No process is required to understand all groups.

## 3. Process model

Each process declares:

```text
reads        state paths or views
writes       delta channels
dt           preferred timescale
units        dimensional contract
conserves    optional invariants
priority     scheduling semantics
```

Processes do not own the global simulation loop.

## 4. Native runtime

The production runtime should eventually use custom Warp/CPU/GPU kernels for:

- neighbor search
- contact/adhesion
- membrane or particle mechanics
- reaction/diffusion/advection
- membrane exchange
- intracellular ODE/stochastic updates
- event detection

The included scaffold only expresses these contracts.

## 5. Specialist solvers

Specialists are connected through adapters:

- SOFA: detailed deformable mechanics / FEM / contact
- ESPResSo: hydrodynamics, soft matter, object-in-fluid regimes
- Tissue Forge: independent multicellular/particle/vertex reference cases
- SBML-capable solvers: intracellular reference dynamics

Specialist solvers may operate in two modes:

1. **offline qualification**: run standardized benchmark cases and compare outputs;
2. **online escalation**: solve a local subproblem when the native solver is outside its validation envelope.

## 6. Multi-fidelity hierarchy

```text
F0  coarse native representation
F1  detailed native representation
F2  specialist solver or qualified surrogate
F3  refined specialist solve with convergence checks
```

Escalation is region- or entity-local whenever possible.

## 7. External entities

An external entity exposes only declared physical interfaces:

```text
geometry
mechanical properties
contact/adhesion law
chemical source/sink law
membrane/surface reaction law
field/boundary contribution
control inputs
```

Examples include nanoparticles, scaffolds, microfluidic walls, drug depots, probes, immune cells, or experimental devices.

## 8. Reproducibility

Every run should be identifiable by:

- model hash
- engine hash
- solver versions
- initial state hash
- random seeds
- mesh/grid hashes
- timestep hierarchy
- tolerances
- units
- hardware/precision
- intervention sequence
- benchmark/reference identifiers

