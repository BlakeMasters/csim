# Validation and Qualification Pyramid

## Levels

0. Mathematical / analytic reference.
1. Numerical convergence and conservation.
2. Cross-engine agreement.
3. Component experimental validation.
4. Single-cell experimental validation.
5. Tissue/organoid validation.
6. Unseen perturbational validation.

## Required metric classes

### Mechanics
- volume/area error
- force-displacement curve
- stress/strain
- relaxation time
- contact area

### Transport
- mass conservation
- concentration L2/Linf error
- penetration depth
- steady-state profile
- membrane flux

### Fluid
- pressure drop
- wall shear
- drag
- velocity profile
- fluid/particle momentum exchange

### Multicellular
- packing fraction
- coordination number
- growth curve
- necrotic/hypoxic fraction
- invasion radius
- lineage composition

## Qualification envelope

Every released model should state where it has evidence of validity, e.g.

```text
cell-cell mechanics        qualified: 0–30% strain
oxygen transport           qualified: 10–200 µm length scale
fluid shear                qualified: 0–3 Pa
ECM remodeling             partial
nuclear rupture            unqualified
```

