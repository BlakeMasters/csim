# Canonical State Contract

## Principle

Backends are replaceable only if biological state is backend-independent.

## Core objects

### CellState

Required minimal fields:

- stable `id`
- optional `parent_id`
- position and velocity/overdamped state
- geometry descriptor
- material/mechanical parameters
- molecular state map
- phenotype map
- lineage generation

### FieldState

A field declares:

- name
- physical units
- spatial discretization metadata
- values or backend handle
- boundary conditions

### ExternalEntity

An external entity is not granted privileged mutation access. It participates through the same force, flux, reaction, or boundary channels as other processes.

## Typed deltas

Processes return deltas rather than mutate the state in-place. This enables:

- deterministic replay;
- rollback/checkpointing;
- conservation auditing;
- competing-process resolution;
- backend A/B comparison.

