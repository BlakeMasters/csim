# Adaptive Fidelity

## Fidelity levels

- **F0:** coarse particle/sphere mechanics, coarse transport.
- **F1:** detailed native mesh/vertex mechanics and refined transport.
- **F2:** specialist solver or qualified reduced-order model.
- **F3:** refined specialist solver with convergence study.

## Escalation signals

A controller may inspect:

- strain or stress magnitude;
- geometry distortion;
- contact multiplicity;
- transport gradients;
- Reynolds/Péclet-like regime indicators;
- surrogate uncertainty;
- distance to previously qualified parameter domain;
- disagreement among independent solvers.

## Example policy

```text
if surrogate_ood > tau_ood:
    F2
elif strain > tau_strain or gradient > tau_gradient:
    F1
else:
    F0
```

If an F2 specialist result disagrees materially with the native model, log the discrepancy and optionally promote that regime into the benchmark/training corpus.

## Surrogate use

A learned correction is permitted only with an attached validity envelope:

```text
parameter bounds
state-domain bounds
error distribution
reference solver/version
training corpus hash
holdout benchmark results
```
