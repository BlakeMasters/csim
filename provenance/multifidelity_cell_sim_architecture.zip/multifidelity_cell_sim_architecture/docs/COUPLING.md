# Solver Coupling

## Partitioned coupling

The recommended architecture is partitioned multiphysics: each solver retains its own discretization and numerical method while exchanging a narrow set of interface variables.

Typical channels:

| Domain A | Domain B | Exchange |
|---|---|---|
| cell mechanics | fluid | traction, velocity, geometry |
| transport | intracellular | concentration, flux, uptake/secretion |
| ECM | mechanics | stiffness, displacement, degradation |
| specialist mechanics | native runtime | displacement, stress, contact forces |

## Coupling loop

```text
state snapshot
   ↓
construct specialist subproblem
   ↓
map canonical state → solver representation
   ↓
solve / iterate
   ↓
map solver output → typed StateDelta
   ↓
validate invariants
   ↓
commit to canonical state
```

## Explicit vs implicit

Use explicit coupling first for weakly coupled regimes. Introduce fixed-point or quasi-Newton/implicit coupling only where stability or accuracy requires it.

## preCICE role

A production implementation can use preCICE for mesh mapping, data exchange, transient coupling, and iterative coupling. Keep preCICE-specific identifiers outside the canonical biological schema.
