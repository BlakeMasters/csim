# Reference Systems and Intended Roles

This architecture is designed to integrate or cross-check against the following classes of tools while keeping the canonical state independent of all of them:

- **Warp/custom kernels** — intended native high-throughput implementation path.
- **SOFA** — specialist deformable mechanics/FEM/contact reference.
- **ESPResSo** — specialist soft-matter/hydrodynamic reference.
- **Tissue Forge** — independent particle/vertex/transport reference cases.
- **preCICE** — optional partitioned multiphysics coupling infrastructure.
- **SBML / SED-ML / OMEX** — model and experiment interchange formats.

No dependency on these systems is required by the scaffold itself.
