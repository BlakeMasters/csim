# Implementation Roadmap

## Stage 0 — contracts
- canonical state
- unit system
- typed deltas
- process API
- deterministic scheduler
- checkpoints/replay

## Stage 1 — minimal native physics
- spherical/particle contact
- overdamped mechanics
- diffusion + source/sink
- simple intracellular state transitions
- division/death events

## Stage 2 — qualification harness
- analytic diffusion benchmark
- contact/relaxation benchmark
- conservation tests
- timestep refinement
- trajectory comparison format

## Stage 3 — specialist adapters
- SOFA mechanics adapter
- ESPResSo flow adapter
- Tissue Forge cross-engine adapter
- optional preCICE coupler

## Stage 4 — detailed native solver
- vertex/membrane representation
- local mesh refinement
- ECM coupling
- advection/reaction-diffusion
- multirate scheduling

## Stage 5 — adaptive fidelity
- escalation metrics
- region-local subproblems
- uncertainty tracking
- discrepancy logging

## Stage 6 — reduced-order learning
- build specialist-solver trajectory corpus
- train correction/surrogate models
- enforce OOD fallback
- qualify learned models on untouched regimes

## Stage 7 — integrated vascularized microtumor
- tumor cells
- ECM
- vessel boundary/flow
- O2/glucose/lactate/drug
- external entities/interventions
- experimental comparison suite
