from __future__ import annotations

from cellsim.core.process import Process, ProcessContract
from cellsim.core.state import WorldState, StateDelta


class UniformDecayTransport(Process):
    """Toy process to exercise field scheduling; replace with PDE kernels."""

    def __init__(self, field_name: str, decay_rate: float, dt: float = 0.1):
        self.field_name = field_name
        self.decay_rate = decay_rate
        self.contract = ProcessContract(
            name=f"transport:{field_name}",
            dt=dt,
            reads=frozenset({f"fields.{field_name}"}),
            writes=frozenset({f"fields.{field_name}"}),
            units={field_name: "model concentration", "time": "s"},
            priority=20,
        )

    def evaluate(self, state: WorldState, dt: float) -> StateDelta:
        field = state.scalar_fields[self.field_name]
        factor = max(0.0, 1.0 - self.decay_rate * dt)
        return StateDelta(
            field_updates={self.field_name: {k: v * factor for k, v in field.values.items()}},
            diagnostics={"factor": factor},
        )
