from __future__ import annotations

from cellsim.core.process import Process, ProcessContract
from cellsim.core.state import WorldState, StateDelta


class HypoxiaResponse(Process):
    """Minimal example of environment → intracellular/phenotype coupling."""

    def __init__(self, threshold: float = 0.2, dt: float = 1.0):
        self.threshold = threshold
        self.contract = ProcessContract(
            name="hypoxia_response",
            dt=dt,
            reads=frozenset({"fields.oxygen", "cells.phenotype"}),
            writes=frozenset({"cells.phenotype"}),
            units={"oxygen": "normalized"},
            priority=30,
        )

    def evaluate(self, state: WorldState, dt: float) -> StateDelta:
        oxygen = state.scalar_fields.get("oxygen")
        updates = {}
        if oxygen:
            for cid in state.cells:
                local = oxygen.values.get(cid, 1.0)
                updates[cid] = {"hypoxic": local < self.threshold}
        return StateDelta(phenotype_updates=updates)
