from __future__ import annotations
from dataclasses import replace

from cellsim.core.process import Process, ProcessContract
from cellsim.core.state import WorldState, StateDelta


class DivisionEventProcess(Process):
    """Deterministic demonstration of discrete-event separation."""

    def __init__(self, dt: float = 10.0):
        self.contract = ProcessContract(
            name="division_events",
            dt=dt,
            reads=frozenset({"cells.phenotype", "cells.lineage"}),
            writes=frozenset({"cells"}),
            priority=100,
        )

    def evaluate(self, state: WorldState, dt: float) -> StateDelta:
        births = []
        updates = {}
        for cell in list(state.cells.values()):
            if cell.phenotype.get("divide", False):
                child_id = f"{cell.id}.g{cell.generation + 1}"
                child = replace(
                    cell,
                    id=child_id,
                    parent_id=cell.id,
                    generation=cell.generation + 1,
                    position=(cell.position[0] + 0.1, cell.position[1], cell.position[2]),
                    phenotype={**cell.phenotype, "divide": False},
                )
                births.append(child)
                updates[cell.id] = {"divide": False}
        return StateDelta(births=births, phenotype_updates=updates)
