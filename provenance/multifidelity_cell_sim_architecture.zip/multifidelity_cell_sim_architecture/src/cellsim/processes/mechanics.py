from __future__ import annotations

from cellsim.core.process import Process, ProcessContract
from cellsim.core.state import WorldState, StateDelta
from cellsim.backends.base import SolverBackend, SolverRequest


class MechanicsProcess(Process):
    def __init__(self, backend: SolverBackend, dt: float = 0.01):
        self.backend = backend
        self.contract = ProcessContract(
            name="mechanics",
            dt=dt,
            reads=frozenset({"cells.position", "cells.geometry", "cells.material"}),
            writes=frozenset({"cells.position"}),
            units={"position": "um", "time": "s"},
            priority=10,
        )

    def evaluate(self, state: WorldState, dt: float) -> StateDelta:
        req = SolverRequest("mechanics", state.cells.keys(), dt)
        return self.backend.solve(state, req).delta
