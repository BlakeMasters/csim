from dataclasses import dataclass
from typing import Dict, Any


@dataclass
class CouplingExchange:
    participant: str
    mesh: str
    write_data: Dict[str, Any]
    read_data: Dict[str, Any]


class PreciceCoupler:
    """Placeholder contract for partitioned multiphysics coupling."""

    def initialize(self) -> None:
        raise NotImplementedError

    def exchange(self, payload: CouplingExchange) -> CouplingExchange:
        raise NotImplementedError

    def finalize(self) -> None:
        raise NotImplementedError
