from .base import SolverBackend, SolverRequest, SolverResult
from cellsim.core.state import WorldState


class EspressoAdapter(SolverBackend):
    name = "espresso"

    def solve(self, state: WorldState, request: SolverRequest) -> SolverResult:
        raise NotImplementedError(
            "Map local fluid/object geometry to ESPResSo and return fluid/traction/deformation outputs."
        )
