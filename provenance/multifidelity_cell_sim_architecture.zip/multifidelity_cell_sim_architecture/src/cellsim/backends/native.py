from __future__ import annotations
from math import sqrt

from .base import SolverBackend, SolverRequest, SolverResult
from cellsim.core.state import WorldState, StateDelta


class NativeReferenceBackend(SolverBackend):
    """Toy dependency-free backend used only to exercise orchestration.

    Replace this with Warp/custom kernels in a production engine.
    """

    name = "native_reference"

    def solve(self, state: WorldState, request: SolverRequest) -> SolverResult:
        delta = StateDelta()
        ids = list(request.entity_ids)
        if request.domain == "mechanics":
            # Minimal pairwise overlap relaxation for architecture tests.
            for i, a_id in enumerate(ids):
                a = state.cells[a_id]
                ax, ay, az = a.position
                fx = fy = fz = 0.0
                for b_id in ids[i + 1:]:
                    b = state.cells[b_id]
                    bx, by, bz = b.position
                    dx, dy, dz = ax - bx, ay - by, az - bz
                    d = sqrt(dx*dx + dy*dy + dz*dz) or 1e-9
                    target = a.geometry.radius + b.geometry.radius
                    overlap = max(0.0, target - d)
                    if overlap:
                        scale = 0.5 * overlap / d
                        fx += dx * scale
                        fy += dy * scale
                        fz += dz * scale
                delta.position_updates[a_id] = (
                    ax + fx * request.dt,
                    ay + fy * request.dt,
                    az + fz * request.dt,
                )
        delta.diagnostics = {"backend": self.name, "domain": request.domain}
        return SolverResult(delta=delta, diagnostics=delta.diagnostics)
