from __future__ import annotations
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Dict, Any, Iterable

from cellsim.core.state import WorldState, StateDelta


@dataclass
class SolverRequest:
    domain: str
    entity_ids: Iterable[str]
    dt: float
    parameters: Dict[str, Any] = field(default_factory=dict)


@dataclass
class SolverResult:
    delta: StateDelta
    diagnostics: Dict[str, Any] = field(default_factory=dict)
    qualification: Dict[str, Any] = field(default_factory=dict)


class SolverBackend(ABC):
    name: str

    @abstractmethod
    def solve(self, state: WorldState, request: SolverRequest) -> SolverResult:
        raise NotImplementedError
