from .base import SolverBackend, SolverRequest, SolverResult
from cellsim.core.state import WorldState


class TissueForgeAdapter(SolverBackend):
    name = "tissue_forge"

    def solve(self, state: WorldState, request: SolverRequest) -> SolverResult:
        raise NotImplementedError(
            "Use Tissue Forge primarily as an independent cross-engine reference implementation."
        )
