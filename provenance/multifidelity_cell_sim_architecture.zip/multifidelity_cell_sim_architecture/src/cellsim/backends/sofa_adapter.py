from .base import SolverBackend, SolverRequest, SolverResult
from cellsim.core.state import WorldState


class SofaAdapter(SolverBackend):
    name = "sofa"

    def solve(self, state: WorldState, request: SolverRequest) -> SolverResult:
        raise NotImplementedError(
            "Map canonical geometry/material/contact state to SOFA, run the subproblem, "
            "then return displacement/stress/contact results as a StateDelta."
        )
