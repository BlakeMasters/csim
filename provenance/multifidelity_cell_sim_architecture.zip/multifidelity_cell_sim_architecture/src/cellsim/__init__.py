"""Multi-fidelity cellular simulation architecture scaffold."""

__all__ = ["core", "backends", "processes"]
