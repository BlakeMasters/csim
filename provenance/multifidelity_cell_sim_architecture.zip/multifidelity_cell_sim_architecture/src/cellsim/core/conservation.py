from __future__ import annotations
from dataclasses import dataclass
from typing import Dict

from .state import WorldState


@dataclass
class ConservationReport:
    before: float
    after: float
    absolute_error: float
    relative_error: float


def total_species(state: WorldState, species: str) -> float:
    total = 0.0
    for cell in state.cells.values():
        total += float(cell.molecular.get(species, 0.0))
    field = state.scalar_fields.get(species)
    if field:
        total += sum(float(v) for v in field.values.values())
    return total


def compare_species(before: WorldState, after: WorldState, species: str) -> ConservationReport:
    a = total_species(before, species)
    b = total_species(after, species)
    err = b - a
    rel = abs(err) / max(abs(a), 1e-12)
    return ConservationReport(a, b, err, rel)
