from __future__ import annotations
from dataclasses import dataclass
from typing import Iterable, List, Dict

from .process import Process
from .state import WorldState


@dataclass
class _Scheduled:
    process: Process
    next_time: float = 0.0


class MultiRateScheduler:
    """Deterministic multirate scheduler for continuous/discrete process orchestration."""

    def __init__(self, processes: Iterable[Process]):
        scheduled = [_Scheduled(p, 0.0) for p in processes]
        self._scheduled: List[_Scheduled] = sorted(
            scheduled,
            key=lambda x: (x.process.contract.priority, x.process.contract.name),
        )

    def advance(self, state: WorldState, until: float) -> Dict[str, list]:
        if until < state.time:
            raise ValueError("cannot run backwards")
        logs: Dict[str, list] = {}
        eps = 1e-12
        while True:
            due = [s for s in self._scheduled if s.next_time <= until + eps]
            if not due:
                break
            t = min(s.next_time for s in due)
            if t < state.time - eps:
                # Process is behind due to a nonzero initial state time. Catch it up.
                for s in due:
                    if s.next_time < state.time:
                        n = int((state.time - s.next_time) // s.process.contract.dt)
                        s.next_time += (n + 1) * s.process.contract.dt
                continue
            state.time = t
            for s in self._scheduled:
                if abs(s.next_time - t) <= eps:
                    p = s.process
                    delta = p.evaluate(state.clone(), p.contract.dt)
                    delta.commit(state)
                    logs.setdefault(p.contract.name, []).append(delta.diagnostics)
                    s.next_time += p.contract.dt
                    state.step += 1
        state.time = until
        return logs
