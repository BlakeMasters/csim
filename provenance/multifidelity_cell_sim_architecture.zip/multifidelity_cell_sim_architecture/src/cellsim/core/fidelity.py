from __future__ import annotations
from dataclasses import dataclass
from enum import IntEnum
from typing import Dict, Any


class FidelityLevel(IntEnum):
    F0_COARSE_NATIVE = 0
    F1_DETAILED_NATIVE = 1
    F2_SPECIALIST = 2
    F3_REFINED_SPECIALIST = 3


@dataclass
class FidelityThresholds:
    strain_f1: float = 0.20
    strain_f2: float = 0.40
    gradient_f1: float = 1.0
    surrogate_ood_f2: float = 0.50
    disagreement_f3: float = 0.15


class FidelityController:
    def __init__(self, thresholds: FidelityThresholds | None = None):
        self.thresholds = thresholds or FidelityThresholds()

    def choose(self, metrics: Dict[str, float]) -> tuple[FidelityLevel, Dict[str, Any]]:
        t = self.thresholds
        disagreement = metrics.get("reference_disagreement", 0.0)
        ood = metrics.get("surrogate_ood", 0.0)
        strain = metrics.get("strain", 0.0)
        gradient = metrics.get("gradient", 0.0)

        if disagreement > t.disagreement_f3:
            level = FidelityLevel.F3_REFINED_SPECIALIST
            reason = "reference disagreement exceeds threshold"
        elif ood > t.surrogate_ood_f2 or strain > t.strain_f2:
            level = FidelityLevel.F2_SPECIALIST
            reason = "native/surrogate regime outside qualification envelope"
        elif strain > t.strain_f1 or gradient > t.gradient_f1:
            level = FidelityLevel.F1_DETAILED_NATIVE
            reason = "local state requires detailed native representation"
        else:
            level = FidelityLevel.F0_COARSE_NATIVE
            reason = "coarse native model is inside qualified regime"
        return level, {"reason": reason, "metrics": dict(metrics)}
