from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple, Any
import copy

Vec3 = Tuple[float, float, float]


@dataclass
class GeometryState:
    kind: str = "sphere"
    radius: float = 1.0
    vertices: List[Vec3] = field(default_factory=list)


@dataclass
class MaterialState:
    elastic_modulus: float = 1.0
    viscosity: float = 1.0
    adhesion: float = 0.0


@dataclass
class CellState:
    id: str
    position: Vec3
    parent_id: Optional[str] = None
    velocity: Vec3 = (0.0, 0.0, 0.0)
    geometry: GeometryState = field(default_factory=GeometryState)
    material: MaterialState = field(default_factory=MaterialState)
    molecular: Dict[str, float] = field(default_factory=dict)
    phenotype: Dict[str, Any] = field(default_factory=dict)
    generation: int = 0


@dataclass
class ExternalEntity:
    id: str
    kind: str
    position: Vec3
    geometry: GeometryState = field(default_factory=GeometryState)
    properties: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ScalarFieldState:
    name: str
    units: str
    values: Dict[str, float] = field(default_factory=dict)


@dataclass
class WorldState:
    time: float = 0.0
    step: int = 0
    cells: Dict[str, CellState] = field(default_factory=dict)
    external_entities: Dict[str, ExternalEntity] = field(default_factory=dict)
    scalar_fields: Dict[str, ScalarFieldState] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def clone(self) -> "WorldState":
        return copy.deepcopy(self)


@dataclass
class StateDelta:
    """Backend/process output. The scheduler commits deltas to canonical state."""

    position_updates: Dict[str, Vec3] = field(default_factory=dict)
    molecular_updates: Dict[str, Dict[str, float]] = field(default_factory=dict)
    phenotype_updates: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    field_updates: Dict[str, Dict[str, float]] = field(default_factory=dict)
    births: List[CellState] = field(default_factory=list)
    deaths: List[str] = field(default_factory=list)
    diagnostics: Dict[str, Any] = field(default_factory=dict)

    def commit(self, state: WorldState) -> None:
        for cid, pos in self.position_updates.items():
            state.cells[cid].position = pos
        for cid, updates in self.molecular_updates.items():
            state.cells[cid].molecular.update(updates)
        for cid, updates in self.phenotype_updates.items():
            state.cells[cid].phenotype.update(updates)
        for fname, updates in self.field_updates.items():
            state.scalar_fields[fname].values.update(updates)
        for cid in self.deaths:
            state.cells.pop(cid, None)
        for cell in self.births:
            if cell.id in state.cells:
                raise ValueError(f"duplicate cell id: {cell.id}")
            state.cells[cell.id] = cell
