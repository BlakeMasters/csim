from __future__ import annotations
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import FrozenSet, Dict, Any

from .state import WorldState, StateDelta


@dataclass(frozen=True)
class ProcessContract:
    name: str
    dt: float
    reads: FrozenSet[str] = field(default_factory=frozenset)
    writes: FrozenSet[str] = field(default_factory=frozenset)
    units: Dict[str, str] = field(default_factory=dict)
    conserves: FrozenSet[str] = field(default_factory=frozenset)
    priority: int = 0


class Process(ABC):
    contract: ProcessContract

    @abstractmethod
    def evaluate(self, state: WorldState, dt: float) -> StateDelta:
        raise NotImplementedError
