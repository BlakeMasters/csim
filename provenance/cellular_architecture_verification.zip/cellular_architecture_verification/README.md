# Cellular architecture verification bundle

**Audit date:** 2026-09-17. This package is a claim audit and reproducibility record, not an improved simulator.

Start with `reports/VERIFICATION_REPORT.md`. The report distinguishes established component methods, proposed architecture, conditional mathematics, executed code checks and unperformed biological validation. `reports/SOURCES.md` records the evidence behind each citation.

## Recorded execution

| Suite | Pass | Fail | Error |
|---|---:|---:|---:|
| Original scaffold tests | 4 | 0 | 0 |
| Added numerical/state requirements | 0 | 8 | 0 |
| Added input/evidence safeguards | 0 | 4 | 0 |
| Added positive controls | 4 | 0 | 0 |

The additional tests were selected to probe known risks; this is not a statistical defect-rate estimate. Some safeguards are proposed acceptance contracts rather than documented original API guarantees. The original implementation itself labels the numerical routines as toys.

## Reproduce

Python 3.10+ and its standard library are sufficient. No network access or package installation is required.

```bash
python reproduce.py
```

The default command returns **exit status 1**, because the added checks fail on the original input. Logs and a fresh extracted source tree are written under `reproductions/`.

To check that the *known audit findings* are reproduced, rather than demand that the unchanged scaffold pass the new tests:

```bash
python reproduce.py --expect-known-findings
```

That command returns 0 only when the original tests/example pass and the same named outcomes for all 16 audit tests reappear. It does not reinterpret those failures as a scientifically correct simulator.

## Contents

- `reports/`: 4,000+ word technical audit and source bibliography.
- `evidence/`: 26-claim matrix, 30-source registry, acceptance outcomes and reproduction summary.
- `tests/`: executable additional acceptance suite and JSON result runner.
- `logs/`: original and added-test execution records.
- `original/`: byte-identical original ZIP and its supplied checksum.
- `reproduce.py`: checksum verification, safe extraction and test execution.
- `MANIFEST.sha256`: checksums for bundled files, excluding the manifest itself.

No specialist engines, GPU kernels, biological data fitting or experimental validation were run. Sources accessed only through abstracts are labeled. No implementation fixes were applied. The third-party source documents are cited, not bundled; source availability and licensing remain with their publishers.
