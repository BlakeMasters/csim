# Primary-source and official-documentation registry

Audit date: 2026-09-17. Access depth is stated per source. A bibliographic record or abstract is not presented as a full methods audit. No paywalled ASME standard was inspected. The single review/proposal (S10) is classified as such and is not used as primary experimental proof.

## S01. Agmon et al. — Vivarium: an interface and engine for integrative multiscale modeling in computational biology (2022)

Type: peer-reviewed primary software paper. Access: full text, sections 2–4.

DOI: 10.1093/bioinformatics/btac049. Source: https://academic.oup.com/bioinformatics/article/38/7/1972/6522109

Supports: Processes, stores, multirate composition, and integrated example models.

Limit: Does not establish a universal sufficient cell state or the correctness of arbitrary coupled modules.

## S02. Sluka et al. — The cell behavior ontology: describing the intrinsic biological behaviors of real and model cells seen as active agents (2014)

Type: peer-reviewed primary ontology paper. Access: full text.

DOI: 10.1093/bioinformatics/btu210. Source: https://pmc.ncbi.nlm.nih.gov/articles/PMC4133580/

Supports: Biological semantics separable from implementation terminology.

Limit: An ontology does not define complete numerical restart or constitutive state.

## S03. Friedman et al. — MultiCellDS: a community-developed standard for curating microenvironment-dependent multicellular data (2016)

Type: preprint / community data-standard proposal. Access: author-institution abstract and bibliographic record.

DOI: 10.1101/090456. Source: https://www.isi.edu/results/publications/13460/multicellds-a-community-developed-standard-for-curating-microenvironment-dependent-multicellular-data/

Supports: Digital cell lines, snapshots, phenotype and microenvironment data.

Limit: The cited publication is bioRxiv; it is not proof of lossless universal solver interoperability.

## S04. Ghaffarizadeh et al. — PhysiCell: An open source physics-based cell simulator for 3-D multicellular systems (2018)

Type: peer-reviewed primary software paper. Access: full text including timestep discussion.

DOI: 10.1371/journal.pcbi.1005991. Source: https://journals.plos.org/ploscompbiol/article?id=10.1371/journal.pcbi.1005991

Supports: Cell agents coupled to substrates; distinct diffusion, mechanics, phenotype time scales.

Limit: Its defaults, convergence and performance do not transfer to the supplied toy scaffold.

## S05. preCICE — Overview of adapters (2026)

Type: official documentation. Access: full page, updated 2026-09-08.

DOI: not applicable. Source: https://precice.org/adapters-overview.html

Supports: Lists official and third-party adapters.

Limit: SOFA, ESPResSo and Tissue Forge are not listed; this is not an exhaustive proof no outside adapter exists.

## S06. preCICE — Step 6: Implicit coupling (2026)

Type: official documentation. Access: full page.

DOI: not applicable. Source: https://precice.org/couple-your-code-implicit-coupling.html

Supports: Iterative coupling requires solver checkpoint/restore and reproducible evaluation.

Limit: preCICE does not implement the participating solver checkpoint internals.

## S07. preCICE — Mapping configuration (2026)

Type: official documentation. Access: full page.

DOI: not applicable. Source: https://precice.org/configuration-mapping.html

Supports: Consistent, conservative and scaled-consistent mappings.

Limit: Global sum preservation is not by itself energy, torque, local flux or biological validity.

## S08. Smith et al. — Verification and reproducible curation of the BioModels repository (2025)

Type: peer-reviewed primary reproducibility study. Access: full text, methods and results.

DOI: 10.1371/journal.pcbi.1013239. Source: https://journals.plos.org/ploscompbiol/article?id=10.1371/journal.pcbi.1013239

Supports: 932 of 1055 ODE models agreed across at least two of five engines; published 2025-12-04.

Limit: Many experiments use generic templates; not all original figures were reproduced. Not a spatial biological-validation study.

## S09. FDA — Assessing the Credibility of Computational Modeling and Simulation in Medical Device Submissions (2023)

Type: official nonbinding final guidance. Access: full PDF text and scope-page screenshot, section III printed page 7.

DOI: not applicable. Source: https://www.fda.gov/media/154985/download

Supports: Risk- and context-dependent credibility framework for first-principles/mechanistic models.

Limit: Standalone ML is excluded; hybrid-model guidance covers first-principles aspects only. No approval of this architecture.

## S10. Tatka et al. — Adapting modeling and simulation credibility standards to computational systems biology (2023)

Type: peer-reviewed review and methodological proposal. Access: full text.

DOI: 10.1186/s12967-023-04290-5. Source: https://pmc.ncbi.nlm.nih.gov/articles/PMC10369698/

Supports: Proposes adaptation of credibility practices to systems biology.

Limit: Proposal/review, not a validation experiment or issued regulatory standard.

## S11. Sajjadinia et al. — Multi-fidelity surrogate modeling through hybrid machine learning for biomechanical and finite element analysis of soft tissues (2022)

Type: peer-reviewed primary computational study. Access: author-institution abstract and bibliographic record; publisher full text inaccessible in this audit.

DOI: 10.1016/j.compbiomed.2022.105699. Source: https://bia.unibz.it/esploro/outputs/journalArticle/Multi-fidelity-surrogate-modeling-through-hybrid-machine/991006420497801241

Supports: Empirical reduced-physics plus learned correction for expensive soft-tissue FE models.

Limit: Not a proof of online tumor-solver switching or experimentally calibrated cancer predictions; no quantitative gains adopted here.

## S12. Kim, Stolarska and Othmer — A hybrid model for tumor spheroid growth in vitro I: Theoretical development and early results (2007)

Type: peer-reviewed primary modeling paper. Access: author-institution abstract and bibliographic record.

DOI: 10.1142/S0218202507002479. Source: https://experts.umn.edu/en/publications/a-hybrid-model-for-tumor-spheroid-growth-in-vitro-i-theoretical-d/

Supports: Cell-level growing periphery, continuum quiescent/necrotic regions and ECM, nutrient fields.

Limit: Prior art for regional model heterogeneity; not the exact proposed heterogeneous-engine controller.

## S13. Agmon and Spangler — Process Bigraphs and the Architecture of Compositional Systems Biology (2026)

Type: preprint. Access: abstract and version history; v2 dated 2026-08-14.

DOI: 10.48550/arXiv.2512.23754. Source: https://arxiv.org/abs/2512.23754

Supports: Typed interfaces, hierarchy, model translation and coordination, Vivarium 2.0 demonstrations.

Limit: Preprint; no peer-reviewed journal status confirmed. Closely related prior art, not a proof of this design.

## S14. Ascheid et al. — A vascularized breast cancer spheroid platform for the ranked evaluation of tumor microenvironment-targeted drugs by light sheet fluorescence microscopy (2024)

Type: peer-reviewed primary experimental paper. Access: full text including model construction and results.

DOI: 10.1038/s41467-024-48010-z. Source: https://www.nature.com/articles/s41467-024-48010-z

Supports: Four human-origin populations, pseudovascular organization, imaging/drug-response phenotypes, and additional in-vivo vascular comparisons.

Limit: The in-vitro spheroid arm does not demonstrate intravascular perfusion. The paper also contains in-vivo perfused-vessel measurements; these must not be confused with spheroid perfusion.

## S15. Quintard et al. — A microfluidic platform integrating functional vascularized organoids-on-chip (2024)

Type: peer-reviewed primary experimental paper. Access: full text.

DOI: 10.1038/s41467-024-45710-4. Source: https://www.nature.com/articles/s41467-024-45710-4

Supports: Functional perfusion of mesenchymal/pancreatic-islet spheroids and blood-vessel organoids.

Limit: Not a cancer-treatment validation dataset; useful vascular-engineering precedent.

## S16. Skubal et al. — Vascularized tumor on a microfluidic chip to study mechanisms promoting tumor neovascularization and vascular targeted therapies (2025)

Type: peer-reviewed primary experimental paper. Access: full text and figure captions.

DOI: 10.7150/thno.95334. Source: https://www.thno.org/v15p0766.htm

Supports: Metastatic renal-cell-carcinoma chip with vessel sprouting, bead and fluorescein experiments.

Limit: Figure 3 bead perfusion n=1 chip and fluorescein n=4; tracer transport and beads are not actual drug PK or deformable blood cells.

## S17. Wang et al. — Calibration of agent based models for monophasic and biphasic tumour growth using approximate Bayesian computation (2024)

Type: peer-reviewed primary modeling/calibration paper. Access: full text, sections 2.1 and 2.2.

DOI: 10.1007/s00285-024-02045-4. Source: https://link.springer.com/article/10.1007/s00285-024-02045-4

Supports: SMC-ABC parameter inference for a 2D Voronoi ABM using mouse xenograft data.

Limit: No cell death; declining late measurements excluded for model-assumption compatibility; breast-labeled MDA-MB435 data require authentication qualification.

## S18. Cellosaurus — MDA-MB-435 (CVCL_0417) (2026)

Type: curated primary biological-resource record. Access: full record.

DOI: not applicable. Source: https://www.cellosaurus.org/CVCL_0417

Supports: Lists MDA-MB-435 as an M14 derivative and registered misidentified cell line.

Limit: A resource-level identity warning does not retrospectively assay the exact historical vial used in an experiment.

## S19. SBML specifications (2026)

Type: official standard documentation. Access: official specification index.

DOI: not applicable. Source: https://sbml.org/documents/specifications/

Supports: Software-independent biological model descriptions and level/package distinctions.

Limit: A file format alone does not establish every solver supports each package or arbitrary dynamic cell geometry.

## S20. SED-ML — Simulation Experiment Description Markup Language (2026)

Type: official standard documentation. Access: official standard overview.

DOI: not applicable. Source: https://sed-ml.org/

Supports: Model modifications, simulation procedures, outputs and experiment exchange.

Limit: The proposed ABM/coupling experiment requires explicit supported mappings; schema existence is not runtime conformance.

## S21. Bergmann et al. — COMBINE archive and OMEX format: one file to share all information to reproduce a modeling project (2014)

Type: peer-reviewed primary software/format paper. Access: full text.

DOI: 10.1186/s12859-014-0369-z. Source: https://link.springer.com/article/10.1186/s12859-014-0369-z

Supports: ZIP-based archive with mandatory manifest and optional metadata; can include additional formats.

Limit: Packaging custom files does not make their semantics executable by independent solvers.

## S22. SOFA — Features (2026)

Type: official software documentation. Access: full page.

DOI: not applicable. Source: https://www.sofa-framework.org/about/features/

Supports: FEM, nonlinear material options, contact and representation mappings.

Limit: Capability documentation is not cancer-cell material calibration or a biological accuracy ranking.

## S23. ESPResSo — Object-in-Fluid (2026)

Type: official software documentation. Access: full page.

DOI: not applicable. Source: https://espressomd.github.io/doc/object_in_fluid.html

Supports: Triangulated elastic objects with stretching, bending, area and volume forces in fluid.

Limit: Cell-like mechanics does not itself validate tumor-cell/nuclear constitutive behavior.

## S24. Tissue Forge — Vertex Model Solver (2026)

Type: official software documentation. Access: full page.

DOI: not applicable. Source: https://tissue-forge-documentation.readthedocs.io/en/latest/models/vertex/solver/solver.html

Supports: Surface/body representation and actor-based mechanics.

Limit: Automatic mesh-quality operations are primarily developed for two-dimensional use; not all 3D dynamic-topology behavior can be presumed.

## S25. NVIDIA Warp — Documentation (2026)

Type: official software documentation. Access: full index/capability overview.

DOI: not applicable. Source: https://nvidia.github.io/warp/stable/index.html

Supports: CPU/CUDA kernels, geometry/numerical primitives and differentiability.

Limit: Does not establish biological credibility, comparative speed on this workload, or differentiability of arbitrary discrete events.

## S26. Bull et al. — Mathematical modelling reveals cellular dynamics within tumour spheroids (2020)

Type: peer-reviewed primary modeling paper. Access: full text, model and oxygen sections.

DOI: 10.1371/journal.pcbi.1007961. Source: https://journals.plos.org/ploscompbiol/article?id=10.1371/journal.pcbi.1007961

Supports: Off-lattice cell model with continuous quasi-steady oxygen and comparison to spheroid-infiltration experiments.

Limit: Reported simulations restricted to 2D; conditional model assumptions, not general 3D perfused-tumor validation.

## S27. Murphy et al. — Growth and adaptation mechanisms of tumour spheroids with time-dependent oxygen availability (2023)

Type: peer-reviewed primary experimental/modeling paper. Access: full text including cell culture methods.

DOI: 10.1371/journal.pcbi.1010833. Source: https://journals.plos.org/ploscompbiol/article?id=10.1371/journal.pcbi.1010833

Supports: Time-dependent oxygen spheroid experiments and growth/adaptation modeling; authenticated melanoma cell lines.

Limit: Provides scoped observables; does not validate the proposed software without matched experiments and held-out predictions.

## S28. Waltemath et al. — Minimum Information About a Simulation Experiment (MIASE) (2011)

Type: peer-reviewed community reporting proposal. Access: full text.

DOI: 10.1371/journal.pcbi.1001122. Source: https://journals.plos.org/ploscompbiol/article?id=10.1371/journal.pcbi.1001122

Supports: Information needed to reproduce model setup, execution and postprocessing.

Limit: Documentation completeness is necessary but not empirical biological accuracy.

## S29. Stöberl et al. — Nuclear deformation and dynamics of migrating cells in 3D confinement reveal adaptation of pulling and pushing forces (2024)

Type: peer-reviewed primary experimental/modeling study. Access: author-institution abstract and bibliographic record; PMC full text blocked.

DOI: 10.1126/sciadv.adm9195. Source: https://research.vu.nl/en/publications/nuclear-deformation-and-dynamics-of-migrating-cells-in-3d-confine/

Supports: Nuclear shapes, displacement-derived forces and migration dynamics in compliant three-dimensional hydrogel channels.

Limit: Supports a confinement-specific mechanics benchmark, not universal strain thresholds or complete cancer-cell constitutive laws.

## S30. Bastianello et al. — Mechanical stress during confined migration causes aberrant mitoses and c-MYC amplification (2024)

Type: peer-reviewed primary experimental study. Access: author-institution full PDF; abstract, results and methods inspected; no numerical figure data digitized.

DOI: 10.1073/pnas.2404551121. Source: https://air.unimi.it/retrieve/dd21f6fc-5335-4270-b5dd-c5c7144e0c5c/pnas.202404551.pdf

Supports: Microfluidic confinement, live imaging and molecular observations connect mitotic confinement with chromosome-segregation defects and oncogenic alterations in studied systems.

Limit: Does not supply a universal deformation-to-mutation equation or validate the proposed simulator.
