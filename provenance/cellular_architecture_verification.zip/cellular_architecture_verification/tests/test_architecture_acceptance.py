"""Independent acceptance probes for the unchanged, supplied scaffold.

Run from the original project root:
    PYTHONPATH=src python -m unittest discover -s /path/to/audit/tests -v

These tests specify minimum numerical/state invariants and proposed fail-closed
contracts. Failures do not establish biological invalidity of an implemented
simulator: the supplied project is explicitly a toy orchestration scaffold.
"""
import math
import unittest

from cellsim.core.state import (CellState, GeometryState, ScalarFieldState,
                                StateDelta, WorldState)
from cellsim.core.scheduler import MultiRateScheduler
from cellsim.core.process import Process, ProcessContract
from cellsim.core.fidelity import FidelityController, FidelityLevel
from cellsim.core.conservation import compare_species, total_species
from cellsim.backends.native import NativeReferenceBackend
from cellsim.backends.base import SolverRequest
from cellsim.processes.transport import UniformDecayTransport
from cellsim.processes.events import DivisionEventProcess


def field_world():
    return WorldState(scalar_fields={
        'x': ScalarFieldState(name='x', units='mol', values={'v': 1.0})})


def pair_world(distance=1.5):
    return WorldState(cells={
        'a': CellState('a', (0.0, 0.0, 0.0)),
        'b': CellState('b', (distance, 0.0, 0.0))})


def run_pair(ids, distance=1.5):
    w = pair_world(distance)
    NativeReferenceBackend().solve(
        w, SolverRequest('mechanics', ids, 0.1)).delta.commit(w)
    return w


class NumericalAndStateRequirements(unittest.TestCase):
    def test_zero_elapsed_time_does_not_evolve_continuous_state(self):
        w = field_world()
        MultiRateScheduler([UniformDecayTransport('x', 0.1, 0.5)]).advance(w, 0.0)
        self.assertEqual(w.scalar_fields['x'].values['v'], 1.0)

    def test_endpoint_integrates_two_not_three_euler_steps(self):
        w = field_world()
        MultiRateScheduler([UniformDecayTransport('x', 0.1, 0.5)]).advance(w, 1.0)
        self.assertAlmostEqual(w.scalar_fields['x'].values['v'], 0.95**2, places=14)

    def test_equal_isolated_pair_preserves_midpoint(self):
        w = run_pair(['a', 'b'])
        midpoint = (w.cells['a'].position[0] + w.cells['b'].position[0]) / 2
        self.assertAlmostEqual(midpoint, 0.75, places=14)

    def test_mechanics_invariant_to_entity_iteration_order(self):
        w1, w2 = run_pair(['a', 'b']), run_pair(['b', 'a'])
        for cid in ('a', 'b'):
            self.assertEqual(w1.cells[cid].position, w2.cells[cid].position)

    def test_instantaneous_division_preserves_total_cell_volume(self):
        # No growth process operates in this instantaneous event.
        w = WorldState(cells={'a': CellState('a', (0, 0, 0), phenotype={'divide': True})})
        initial = sum(c.geometry.radius**3 for c in w.cells.values())
        DivisionEventProcess().evaluate(w.clone(), 1.0).commit(w)
        final = sum(c.geometry.radius**3 for c in w.cells.values())
        self.assertAlmostEqual(final, initial, places=14)

    def test_second_division_of_retained_parent_has_unique_id(self):
        w = WorldState(cells={'a': CellState('a', (0, 0, 0), phenotype={'divide': True})})
        p = DivisionEventProcess()
        p.evaluate(w.clone(), 1.0).commit(w)
        w.cells['a'].phenotype['divide'] = True
        try:
            p.evaluate(w.clone(), 1.0).commit(w)
        except ValueError as e:
            self.fail(f'repeated division must not collide with an existing id: {e}')
        self.assertEqual(len(w.cells), 3)

    def test_rejected_delta_does_not_partially_mutate_world(self):
        w = pair_world()
        initial = w.clone()
        d = StateDelta(position_updates={'a': (99, 0, 0)},
                       births=[CellState('b', (0, 0, 0))])
        with self.assertRaises(ValueError):
            d.commit(w)
        self.assertEqual(w, initial)

    def test_absolute_error_is_nonnegative(self):
        before = field_world()
        after = before.clone()
        after.scalar_fields['x'].values['v'] = 0.5
        self.assertEqual(compare_species(before, after, 'x').absolute_error, 0.5)


class ProposedInputAndEvidenceSafeguards(unittest.TestCase):
    """These are required safeguards, not claims that the old API promised them."""
    def test_zero_process_timestep_rejected_before_execution(self):
        # Do not call advance: dt=0 would otherwise cause nontermination.
        with self.assertRaises((ValueError, TypeError)):
            MultiRateScheduler([UniformDecayTransport('x', 0.1, 0.0)])

    def test_nonfinite_fidelity_metric_rejected(self):
        with self.assertRaises((ValueError, TypeError)):
            FidelityController().choose({'strain': math.nan})

    def test_missing_metrics_do_not_assert_scientific_qualification(self):
        level, diagnostics = FidelityController().choose({})
        self.assertNotIn('inside qualified regime', diagnostics['reason'])

    def test_declared_write_contract_is_enforced(self):
        class UnauthorizedWrite(Process):
            contract = ProcessContract('bad', 0.1, writes=frozenset())
            def evaluate(self, state, dt):
                return StateDelta(position_updates={'a': (99, 0, 0)})
        w = pair_world()
        with self.assertRaises((ValueError, PermissionError)):
            MultiRateScheduler([UnauthorizedWrite()]).advance(w, 0.1)


class PositiveControls(unittest.TestCase):
    def test_no_overlap_produces_no_motion(self):
        w = run_pair(['a', 'b'], distance=3.0)
        self.assertEqual(w, pair_world(distance=3.0))

    def test_manual_equal_unit_amount_exchange_preserves_total(self):
        before = field_world()
        before.cells['a'] = CellState('a', (0, 0, 0), molecular={'x': 0.0})
        after = before.clone()
        after.scalar_fields['x'].values['v'] -= 0.25
        after.cells['a'].molecular['x'] += 0.25
        self.assertEqual(total_species(before, 'x'), total_species(after, 'x'))

    def test_world_clone_is_independent(self):
        w = pair_world()
        copy = w.clone()
        copy.cells['a'].geometry.radius = 10.0
        self.assertEqual(w.cells['a'].geometry.radius, 1.0)

    def test_scheduler_rejects_backwards_time(self):
        w = field_world()
        w.time = 2.0
        with self.assertRaises(ValueError):
            MultiRateScheduler([]).advance(w, 1.0)


if __name__ == '__main__':
    unittest.main(verbosity=2)
