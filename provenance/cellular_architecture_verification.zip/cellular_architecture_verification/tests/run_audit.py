"""Run acceptance probes and emit machine-readable results.

Usage: python run_audit.py --project PATH --output PATH
The original project is imported; it is not patched.
"""
import argparse
import json
from pathlib import Path
import sys
import time
import unittest

parser = argparse.ArgumentParser()
parser.add_argument('--project', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
sys.path.insert(0, str(args.project.resolve() / 'src'))

class RecordingResult(unittest.TextTestResult):
    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self.records = []
    def addSuccess(self, test):
        super().addSuccess(test)
        self.records.append({'test': test.id(), 'outcome': 'PASS'})
    def addFailure(self, test, err):
        super().addFailure(test, err)
        self.records.append({'test': test.id(), 'outcome': 'FAIL',
                             'detail': self._exc_info_to_string(err, test)})
    def addError(self, test, err):
        super().addError(test, err)
        self.records.append({'test': test.id(), 'outcome': 'ERROR',
                             'detail': self._exc_info_to_string(err, test)})

suite = unittest.defaultTestLoader.discover(str(Path(__file__).parent),
                                          pattern='test_architecture_acceptance.py')
start = time.perf_counter()
result = unittest.TextTestRunner(verbosity=2, resultclass=RecordingResult).run(suite)
summary = {'tests': result.testsRun, 'passed': result.testsRun-len(result.failures)-len(result.errors),
           'failures': len(result.failures), 'errors': len(result.errors),
           'elapsed_seconds': time.perf_counter()-start, 'python': sys.version,
           'project': str(args.project.resolve()), 'records': result.records}
args.output.parent.mkdir(parents=True, exist_ok=True)
args.output.write_text(json.dumps(summary, indent=2))
raise SystemExit(0 if result.wasSuccessful() else 1)
