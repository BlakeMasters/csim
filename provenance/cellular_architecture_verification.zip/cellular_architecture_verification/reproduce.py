#!/usr/bin/env python3
"""Reproduce the audit against the byte-identical, unmodified input archive.

Python >= 3.10; standard library only. No downloads, installations or model training.
Default exit status is nonzero when the acceptance suite fails (expected).
--expect-known-findings succeeds only if the original tests/example pass and the
same named acceptance outcomes as the recorded audit are reproduced.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat
import subprocess
import sys
import tempfile
import zipfile

EXPECTED_SHA256 = 'e0e7df515b25389598123943400377729accbbb7874c865feb5f677e98a7b5c1'
MAX_EXTRACTED_BYTES = 50 * 1024 * 1024


def safe_extract(archive: Path, destination: Path) -> None:
    """Extract only relative regular files/directories, with no overwrite."""
    with zipfile.ZipFile(archive) as z:
        if sum(info.file_size for info in z.infolist()) > MAX_EXTRACTED_BYTES:
            raise ValueError('Unexpectedly large input archive')
        for info in z.infolist():
            rel = PurePosixPath(info.filename)
            if (rel.is_absolute() or '..' in rel.parts or '\\' in info.filename
                    or any(':' in part for part in rel.parts)):
                raise ValueError(f'Unsafe archive member: {info.filename!r}')
            mode = (info.external_attr >> 16) & 0xFFFF
            kind = stat.S_IFMT(mode)
            if kind not in (0, stat.S_IFREG, stat.S_IFDIR):
                raise ValueError(f'Unsupported archive member type: {info.filename!r}')
            target = destination.joinpath(*rel.parts)
            if info.is_dir():
                target.mkdir(parents=True, exist_ok=True)
            else:
                target.parent.mkdir(parents=True, exist_ok=True)
                with target.open('xb') as out:
                    out.write(z.read(info))


def run(command: list[str], cwd: Path, env: dict[str, str], log: Path) -> int:
    try:
        result = subprocess.run(command, cwd=cwd, env=env, text=True,
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                timeout=60, check=False)
    except subprocess.TimeoutExpired as exc:
        output = exc.stdout or ''
        if isinstance(output, bytes):
            output = output.decode('utf-8', errors='replace')
        log.write_text(output + '\nTIMEOUT: 60 seconds\n', encoding='utf-8')
        return 124
    log.write_text(result.stdout, encoding='utf-8')
    return result.returncode


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--expect-known-findings', action='store_true')
    parser.add_argument('--output', type=Path,
                        help='Parent directory for a fresh reproduction subdirectory')
    args = parser.parse_args()
    if sys.version_info < (3, 10):
        parser.error('Python >= 3.10 is required by the original scaffold')
    root = Path(__file__).resolve().parent
    archive = root/'original/multifidelity_cell_sim_architecture.zip'
    digest = hashlib.sha256(archive.read_bytes()).hexdigest()
    if digest != EXPECTED_SHA256:
        raise ValueError(f'Original archive checksum mismatch: {digest}')
    parent = (args.output or root/'reproductions').resolve()
    parent.mkdir(parents=True, exist_ok=True)
    prefix = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ_')
    output = Path(tempfile.mkdtemp(prefix=prefix, dir=parent))
    extracted = output/'extracted'
    extracted.mkdir()
    safe_extract(archive, extracted)
    project = extracted/'multifidelity_cell_sim_architecture'
    if not (project/'src/cellsim/core/state.py').is_file():
        raise ValueError('Unexpected original project layout')
    env = dict(os.environ)
    env['PYTHONPATH'] = str(project/'src')
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    original_rc = run([sys.executable, '-m', 'unittest', 'discover', '-s', 'tests', '-v'],
                      project, env, output/'original_tests.txt')
    example_rc = run([sys.executable, '-m', 'examples.run_microtumor'],
                     project, env, output/'original_example.txt')
    acceptance_rc = run([sys.executable, str(root/'tests/run_audit.py'),
                         '--project', str(project), '--output',
                         str(output/'acceptance_results.json')],
                        project, env, output/'acceptance_tests.txt')
    observed = json.loads((output/'acceptance_results.json').read_text())
    recorded = json.loads((root/'evidence/acceptance_results.json').read_text())
    named = lambda data: {record['test']: record['outcome'] for record in data['records']}
    match = (original_rc == 0 and example_rc == 0 and acceptance_rc == 1
             and named(observed) == named(recorded)
             and (observed['tests'], observed['passed'], observed['failures'],
                  observed['errors']) == (16, 4, 12, 0))
    summary = {'input_sha256': digest, 'python': sys.version,
               'original_tests_returncode': original_rc,
               'original_example_returncode': example_rc,
               'acceptance_returncode': acceptance_rc,
               'known_named_outcomes_match': match,
               'output_directory': str(output)}
    (output/'reproduction_summary.json').write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary, indent=2))
    print(f"Acceptance: {observed['passed']} pass; {observed['failures']} fail; "
          f"{observed['errors']} errors. These are expected audit findings, not fixes.")
    if args.expect_known_findings:
        return 0 if match else 1
    return 0 if original_rc == example_rc == acceptance_rc == 0 else 1


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (OSError, ValueError, zipfile.BadZipFile, KeyError) as exc:
        print(f'Reproduction failed: {exc}', file=sys.stderr)
        raise SystemExit(2)
